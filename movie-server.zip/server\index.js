import bcrypt from "bcryptjs";
import cors from "cors";
import express from "express";
import { requireAuth, signToken } from "./auth.js";
import { getPool, sql } from "./db.js";

const app = express();
const port = Number(process.env.PORT ?? 3001);

app.use(cors({ origin: true }));
app.use(express.json({ limit: "2mb" }));

function normalizeUsername(username) {
  return String(username ?? "").trim().toLowerCase();
}

function normalizeDisplayName(displayName, username) {
  return String(displayName ?? "").trim() || username;
}

function publicUser(row) {
  return {
    id: row.id,
    username: row.username,
    displayName: row.display_name,
  };
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

app.post("/api/auth/register", async (req, res, next) => {
  try {
    const username = normalizeUsername(req.body.username);
    const password = String(req.body.password ?? "");
    const displayName = normalizeDisplayName(req.body.displayName, username);

    if (!/^[a-z0-9_@.-]{3,40}$/.test(username)) {
      return res.status(400).json({ error: "用户名需为 3-40 位，可包含字母、数字、下划线、点、横线或 @。" });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: "密码至少需要 6 位。" });
    }

    const pool = await getPool();
    const existing = await pool
      .request()
      .input("username", sql.NVarChar(80), username)
      .query("SELECT id FROM dbo.Users WHERE username = @username");

    if (existing.recordset.length) {
      return res.status(409).json({ error: "这个用户名已经被注册。" });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const result = await pool
      .request()
      .input("username", sql.NVarChar(80), username)
      .input("passwordHash", sql.NVarChar(255), passwordHash)
      .input("displayName", sql.NVarChar(80), displayName)
      .query(`
        INSERT INTO dbo.Users (username, password_hash, display_name)
        OUTPUT INSERTED.id, INSERTED.username, INSERTED.display_name
        VALUES (@username, @passwordHash, @displayName)
      `);

    const user = publicUser(result.recordset[0]);
    res.status(201).json({ token: signToken(user), user });
  } catch (error) {
    next(error);
  }
});

app.post("/api/auth/login", async (req, res, next) => {
  try {
    const username = normalizeUsername(req.body.username);
    const password = String(req.body.password ?? "");

    const pool = await getPool();
    const result = await pool
      .request()
      .input("username", sql.NVarChar(80), username)
      .query("SELECT id, username, display_name, password_hash FROM dbo.Users WHERE username = @username");

    const row = result.recordset[0];
    if (!row || !(await bcrypt.compare(password, row.password_hash))) {
      return res.status(401).json({ error: "用户名或密码不正确。" });
    }

    const user = publicUser(row);
    res.json({ token: signToken(user), user });
  } catch (error) {
    next(error);
  }
});

app.get("/api/auth/me", requireAuth, (req, res) => {
  res.json({ user: req.user });
});

app.get("/api/state", requireAuth, async (req, res, next) => {
  try {
    const pool = await getPool();
    const result = await pool
      .request()
      .input("userId", sql.UniqueIdentifier, req.user.id)
      .query("SELECT state_json FROM dbo.UserAppStates WHERE user_id = @userId");

    const raw = result.recordset[0]?.state_json;
    res.json({ state: raw ? JSON.parse(raw) : null });
  } catch (error) {
    next(error);
  }
});

app.put("/api/state", requireAuth, async (req, res, next) => {
  try {
    const state = req.body?.state;
    if (!state || typeof state !== "object") {
      return res.status(400).json({ error: "缺少有效的 state 数据。" });
    }

    const pool = await getPool();
    await pool
      .request()
      .input("userId", sql.UniqueIdentifier, req.user.id)
      .input("stateJson", sql.NVarChar(sql.MAX), JSON.stringify(state))
      .query(`
        MERGE dbo.UserAppStates AS target
        USING (SELECT @userId AS user_id, @stateJson AS state_json) AS source
        ON target.user_id = source.user_id
        WHEN MATCHED THEN
          UPDATE SET state_json = source.state_json, updated_at = SYSUTCDATETIME()
        WHEN NOT MATCHED THEN
          INSERT (user_id, state_json) VALUES (source.user_id, source.state_json);
      `);

    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(500).json({ error: "服务器处理失败，请稍后重试。" });
});

app.listen(port, "127.0.0.1", () => {
  console.log(`CineList API listening on http://127.0.0.1:${port}`);
});
